# FarmEc
### Authors:
### Swarnamythili R
### Kavin Krishna S
### Solai Meenal E
### Kavi priyan M
# Android Application for improving agricultural sector.It is multi platform service. 
# This app contains ecommerce, Agri media , donation portal and AI chatbot.
# Language Used: XML for front end, JAVA 
# Database & Authentication: Firebase
