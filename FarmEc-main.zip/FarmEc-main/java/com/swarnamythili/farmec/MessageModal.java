package com.swarnamythili.farmec;
public class MessageModal {

    // string to store our message and sender
    private String cnt;


    // constructor.
    public MessageModal(String cnt) {
        this.cnt = cnt;

    }

    // getter and setter methods.
    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }


}

